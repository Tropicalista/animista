const allowedBlocks = [ 'core/paragraph', 'core/heading', 'core/button', 'core/group', 'core/image' ];

export default allowedBlocks;