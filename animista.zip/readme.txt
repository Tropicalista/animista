=== Animista ===
Contributors: Tropicalista
Tags: animate.css, animate blocks, animation
Requires at least: 4.7
Tested up to: 5.5.0
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.

== Description ==

This plugin add some configuration settings to your block to animate it.

Select a block and add some animations in the block inspector panel.

You will have all animations provided by animate.css.

Animate Gutenberg blocks when they scroll into view.

Works with all existing Gutenberg blocks
Choose from 27 different animations
Configure animation with custom delays, offsets and durations
Based on https://animate.style/

== Changelog ==

First release